import React from "react";
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Index from "../screen/Index";
import ProductDetails from "../screen/ProductDetails";

const Routing=()=>{
    return(
        <div>
            <Router>
                <Routes>
                    <Route path='/' element={<Index/>}></Route>
                    <Route path='/productdetails/:pid' element={<ProductDetails/>}>product details</Route>
                </Routes>
            </Router>
        </div>
    )
}

export default Routing