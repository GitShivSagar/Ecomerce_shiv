import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { PRODUCT_DETAILS } from '../utility/Constant'
import { useParams } from 'react-router-dom'

const ProductDetails = () => {
	const [sizeArr, setsizeArr] = useState([])
	const [colorArr, setcolorArr] = useState([])
	const [pdetails, setpdetails] = useState({})
	const { pid } = useParams()

	const getProductDetails = () => {
		axios.get(PRODUCT_DETAILS + pid)
			.then((response) => {
				console.log(response)
				setpdetails(response.data.productdetails)
				const { product_size, product_color } = response.data.productdetails
				setsizeArr(product_size.split(","))
				setcolorArr(product_color.split(","))
			})
			.catch((err) => {
				console.log(err)
			})
	}

	useEffect(() => {
		getProductDetails()
	}, [])

	return (
		<div>
			<div className="col-md-6 col-lg-5 p-b-30">
				<div className="p-r-50 p-t-5 p-lr-0-lg">
					<h4 className="mtext-105 cl2 js-name-detail p-b-14">
						{pdetails.product_brand}&nbsp;{pdetails.product_variant_name}
					</h4>

					<span className="mtext-106 cl2">
						&#8377;{pdetails.product_sp} <small><del className='cl13'>&#8377;{pdetails.product_mrp}</del></small>
						<span className='cl14'>&nbsp;{pdetails.product_discount}% Off</span>
					</span>

					<p className="mtext-104 cl3 p-t-15">
						{pdetails.product_description}
					</p>

					<div className="p-t-33">
						<div className="flex-w flex-r-m p-b-10">
							<div className="size-203 flex-c-m respon6">
								Size
							</div>

							<div className="size-204 respon6-next">
								<div className="rs1-select2 bor8 bg0">
									<select className="js-select2" name="time">
										<option>Choose an option</option>
										{sizeArr.map((sizedata, index) => {
											<option value={sizedata}
											 key={index}>
												{sizedata}
											</option>
										})}
									</select>
									<div className="dropDownSelect2"></div>
								</div>
							</div>
						</div>

						<div className="flex-w flex-r-m p-b-10">
							<div className="size-203 flex-c-m respon6">
								Color
							</div>

							<div className="size-204 respon6-next">
								<div className="rs1-select2 bor8 bg0">
									<select className="js-select2" name="time">
										<option>Choose an option</option>
										{colorArr.map((colordata,index)=>{
											<option value={colordata}
											key={index}>
												{colordata}
											</option>
										})}
									</select>
									<div className="dropDownSelect2"></div>
								</div>
							</div>
						</div>

						<div className="flex-w flex-r-m p-b-10">
							<div className="size-204 flex-w flex-m respon6-next">
								<div className="wrap-num-product flex-w m-r-20 m-tb-10">
									<div className="btn-num-product-down cl8 hov-btn3 trans-04 flex-c-m">
										<i className="fs-16 zmdi zmdi-minus"></i>
									</div>

									<input className="mtext-104 cl3 txt-center num-product" type="number" name="num-product" value="1" />

									<div className="btn-num-product-up cl8 hov-btn3 trans-04 flex-c-m">
										<i className="fs-16 zmdi zmdi-plus"></i>
									</div>
								</div>

								<button className="flex-c-m stext-101 cl0 size-101 bg1 bor1 hov-btn1 p-lr-15 trans-04 js-addcart-detail">
									Add to cart
								</button>
							</div>
						</div>
					</div>
					<div className="flex-w flex-m p-l-100 p-t-40 respon7">
						<div className="flex-m bor9 p-r-10 m-r-11">
							<a href="#" className="fs-14 cl3 hov-cl1 trans-04 lh-10 p-lr-5 p-tb-2 js-addwish-detail tooltip100" data-tooltip="Add to Wishlist">
								<i className="zmdi zmdi-favorite"></i>
							</a>
						</div>

						<a href="#" className="fs-14 cl3 hov-cl1 trans-04 lh-10 p-lr-5 p-tb-2 m-r-8 tooltip100" data-tooltip="Facebook">
							<i className="fa fa-facebook"></i>
						</a>

						<a href="#" className="fs-14 cl3 hov-cl1 trans-04 lh-10 p-lr-5 p-tb-2 m-r-8 tooltip100" data-tooltip="Twitter">
							<i className="fa fa-twitter"></i>
						</a>

						<a href="#" className="fs-14 cl3 hov-cl1 trans-04 lh-10 p-lr-5 p-tb-2 m-r-8 tooltip100" data-tooltip="Google Plus">
							<i className="fa fa-google-plus"></i>
						</a>
					</div>
				</div>
			</div>
		</div>
	)
}

export default ProductDetails