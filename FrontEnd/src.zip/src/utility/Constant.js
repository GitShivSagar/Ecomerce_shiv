const BASE_URL='http://localhost:5000/'
export const PRODUCTS=BASE_URL+'products'
export const PRODUCT_DETAILS=BASE_URL+'productdetails?pid='